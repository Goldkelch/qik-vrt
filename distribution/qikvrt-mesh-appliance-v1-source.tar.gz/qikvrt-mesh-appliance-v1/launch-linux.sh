#!/bin/sh
set -eu
runtime=${CONTAINER_RUNTIME:-}
if [ -z "$runtime" ]; then
  if command -v docker >/dev/null 2>&1; then runtime=docker
  elif command -v podman >/dev/null 2>&1; then runtime=podman
  else echo "Docker or Podman is required" >&2; exit 69
  fi
fi
root=$(CDPATH= cd -- "$(dirname "$0")/../.." && pwd)
mkdir -p "$(dirname "$0")/output"
"$runtime" build --platform linux/amd64 -f "$root/distribution/qikvrt-mesh-appliance-v1/Dockerfile" -t qikvrt-mesh-appliance:v1 "$root"
"$runtime" run --rm --platform linux/amd64 -v "$(dirname "$0")/output:/out" qikvrt-mesh-appliance:v1 "${1:-all}"
