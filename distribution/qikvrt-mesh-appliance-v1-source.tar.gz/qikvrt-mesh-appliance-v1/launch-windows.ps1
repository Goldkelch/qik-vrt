$ErrorActionPreference = "Stop"
$Root = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
$Output = Join-Path $PSScriptRoot "output"
New-Item -ItemType Directory -Force -Path $Output | Out-Null
docker build --platform linux/amd64 -f (Join-Path $Root "distribution\qikvrt-mesh-appliance-v1\Dockerfile") -t qikvrt-mesh-appliance:v1 $Root
$Mode = if ($args.Count -gt 0) { $args[0] } else { "all" }
docker run --rm --platform linux/amd64 -v "${Output}:/out" qikvrt-mesh-appliance:v1 $Mode
