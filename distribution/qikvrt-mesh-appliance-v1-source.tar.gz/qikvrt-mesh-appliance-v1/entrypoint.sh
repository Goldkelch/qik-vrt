#!/bin/sh
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
set -eu
ROOT=/opt/qikvrt
OUT=${QIKVRT_OUTPUT_DIR:-/out}
mkdir -p "$OUT"
mode=${1:-verify}

acquire_geckodriver() {
  dir=/tmp/qikvrt-geckodriver
  rm -rf "$dir"; mkdir -p "$dir"
  curl --fail --location --retry 3 \
    'https://api.github.com/repos/mozilla/geckodriver/releases/tags/v0.37.1' \
    -o "$dir/release.json"
  python3 - "$dir/release.json" "$dir/asset.env" <<'PY'
import json,sys
p=json.load(open(sys.argv[1]))
a=next(x for x in p["assets"] if x["name"]=="geckodriver-v0.37.1-linux64.tar.gz")
assert isinstance(a.get("digest"),str) and a["digest"].startswith("sha256:")
open(sys.argv[2],"w").write("URL="+a["browser_download_url"]+"\nSHA256="+a["digest"].split(":",1)[1]+"\n")
PY
  . "$dir/asset.env"
  curl --fail --location --retry 3 "$URL" -o "$dir/geckodriver.tar.gz"
  printf '%s  %s\n' "$SHA256" "$dir/geckodriver.tar.gz" | sha256sum -c -
  tar -xzf "$dir/geckodriver.tar.gz" -C "$dir"
  echo "$dir/geckodriver"
}

verify() {
  python3 "$ROOT/distribution/qikvrt-mesh-appliance-v1/fetch_overlay.py" \
    --lock "$ROOT/distribution/qikvrt-mesh-appliance-v1/APPLIANCE_LOCK.json" --root "$ROOT"
  /usr/local/bin/qikbrow-host "$ROOT/distribution/qikvrt-mesh-appliance-v1/sample.html" \
    > "$OUT/qikbrow-host.txt"
  grep -q 'QIK-VRT Virtual Appliance' "$OUT/qikbrow-host.txt"
  firefox-esr --version > "$OUT/firefox-version.txt"
  hatari --version > "$OUT/hatari-version.txt" 2>&1 || true
  sha256sum "$ROOT/distribution/qikvrt-mesh-appliance-v1/APPLIANCE_LOCK.json" \
    "$OUT/qikbrow-host.txt" > "$OUT/verify.sha256"
  echo 'QIKVRT_VIRTUAL_APPLIANCE_VERIFY=OBSERVED'
}

firefox_effect_ack() {
  verify
  proof="$OUT/firefox-effect-ack"
  rm -rf "$proof"; mkdir -p "$proof/profile-root"
  (cd "$ROOT/browser/firefox/qikvrt-terminal" && zip -qr "$proof/qikvrt-terminal.xpi" .)
  python3 -B "$ROOT/src/qikvrt_effect_ack_http_terminal.py" >"$proof/backend.log" 2>&1 &
  backend_pid=$!
  trap 'kill "$backend_pid" 2>/dev/null || true' EXIT INT TERM
  ready=0
  for i in $(seq 1 100); do
    if curl -fsS http://127.0.0.1:8771/.well-known/effect-ack >"$proof/discovery.json"; then ready=1; break; fi
    sleep 0.1
  done
  test "$ready" -eq 1
  gecko="$(acquire_geckodriver)"
  QIKVRT_SOURCE_HEAD="${QIKVRT_SOURCE_HEAD:-UNBOUND}" \
  QIKVRT_SOURCE_TREE="${QIKVRT_SOURCE_TREE:-UNBOUND}" \
  python3 -B "$ROOT/tools/qikvrt_firefox_terminal_e2e.py" \
    --geckodriver "$gecko" \
    --xpi "$proof/qikvrt-terminal.xpi" \
    --receipt "$proof/browser-receipt.json" \
    --geckodriver-log "$proof/geckodriver.log" \
    --profile-root "$proof/profile-root"
  curl -fsS http://127.0.0.1:8771/terminal/state >"$proof/backend-state.json"
  python3 - "$proof/browser-receipt.json" "$proof/backend-state.json" <<'PY'
import json,sys
b=json.load(open(sys.argv[1])); s=json.load(open(sys.argv[2]))
assert b["firefox_terminal_execution_observed"] is True
assert b["bounded_loopback_effect_ack_done"] is True
assert b["external_effect"]=="NONE"
assert s["events"]==1 and s["last_event"]["kind"]=="TERMINAL_INPUT_ACCEPTED"
assert s["last_event"]["external_effect"]=="NONE"
print("BOUNDED_LOOPBACK_TERMINAL_INPUT_ACK=OBSERVED")
PY
  sha256sum "$proof"/* > "$proof/SHA256SUMS.txt" 2>/dev/null || true
}

atari() {
  verify
  proof="$OUT/atari"
  rm -rf "$proof"; mkdir -p "$proof/drive"
  python3 "$ROOT/tools/qikvrt_m68000_tos_consumer.py" \
    --output "$proof/drive/MLP.TOS" --hex-output "$proof/MLP.TOS.hex" \
    > "$proof/build.json"
  archive="$proof/emutos-512k-1.4.zip"
  curl --location --fail --retry 5 --retry-all-errors \
    -o "$archive" 'https://downloads.sourceforge.net/project/emutos/emutos/1.4/emutos-512k-1.4.zip'
  echo '1ef7bd25f61bcfc66d19debc2f0ebb0d5e5ba811ccd7f0fddfcb105bb72d1663  '"$archive" | sha256sum -c -
  entry=$(unzip -Z1 "$archive" | awk '/(^|\/)etos512us\.img$/ {print; exit}')
  test -n "$entry"
  unzip -p "$archive" "$entry" > "$proof/etos512us.img"
  test "$(stat -c %s "$proof/etos512us.img")" -eq 524288
  SDL_AUDIODRIVER=dummy xvfb-run -a timeout 90s hatari \
    --tos "$proof/etos512us.img" --machine megast --cpulevel 0 --cpuclock 8 \
    --compatible yes --cpu-exact yes --sound off --fast-forward yes \
    --confirm-quit no --alert-level fatal --harddrive "$proof/drive" \
    --protect-hd off --gemdos-case upper --auto 'C:\MLP.TOS' --run-vbls 3000 \
    --log-level debug --log-file "$proof/hatari.log" \
    --trace gemdos --trace-file "$proof/hatari-trace.log"
  test -s "$proof/drive/QIKVRT.RCP"
  python3 "$ROOT/tools/qikvrt_m68000_tos_consumer.py" \
    --verify-receipt "$proof/drive/QIKVRT.RCP" > "$proof/reobservation.json"
  sha256sum "$proof/drive/MLP.TOS" "$proof/drive/QIKVRT.RCP" \
    "$proof/etos512us.img" > "$proof/SHA256SUMS.txt"
  echo 'VIRTUAL_HATARI_MEGAST_EXECUTION=OBSERVED'
}

case "$mode" in
  verify) verify ;;
  firefox-effect-ack) firefox_effect_ack ;;
  atari) atari ;;
  all) atari; firefox_effect_ack ;;
  *) echo "usage: qikvrt-appliance {verify|atari|firefox-effect-ack|all}" >&2; exit 64 ;;
esac
