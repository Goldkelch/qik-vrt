#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
"""Fetch exact source overlays and verify their Git blob identities."""
from __future__ import annotations
import argparse, hashlib, json, pathlib, urllib.request

def git_blob_sha1(data: bytes) -> str:
    return hashlib.sha1(b"blob " + str(len(data)).encode("ascii") + b"\0" + data).hexdigest()

def main() -> int:
    p=argparse.ArgumentParser()
    p.add_argument("--lock",type=pathlib.Path,required=True)
    p.add_argument("--root",type=pathlib.Path,required=True)
    a=p.parse_args()
    lock=json.loads(a.lock.read_text(encoding="utf-8"))
    for item in lock["exact_overlays"]:
        with urllib.request.urlopen(item["url"], timeout=60) as response:
            data=response.read()
        actual=git_blob_sha1(data)
        if actual != item["git_blob_sha1"]:
            raise SystemExit(f"BLOCK overlay blob mismatch {item['name']}: {actual}")
        target=a.root/item["destination"]
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(data)
        print(json.dumps({"name":item["name"],"git_blob_sha1":actual,"path":str(target)},sort_keys=True))
    return 0
if __name__=="__main__":
    raise SystemExit(main())
