# QIK-VRT Mesh Virtual Appliance V1

This directory turns already repository-bound virtual evidence into a reproducible distribution surface.

## Exact source binding

- Authority Atari/Hatari generation: `3cb6273924f3de310e3bd1cd5b827e8e3529220a` / tree `864b7728c1c52687e4a11668bf0a2ee3fec08365`
- ANSI C89 browser source: `cba166e45a0ea4b5d5dd2ef9cde0ad96ff57554b` / tree `23586fd719627a6e508724239a71b71fea7e9847`
- Firefox bounded Effect-Ack source: `b7c9fa5f74cb963ba7cfefed2a0d0a071e6515a9` / tree `d02211d8f801ddf58a1909c3277b83e8014e0978`
- Firefox live observation: `42eab8223988c9576b3c4be7f9a70c3cba45c5e9` / tree `0cfbe47ce74b301dbab1c15c1c2f7a0fab024045`
- Guest TCP/IP source: `a71484ba02f6ebe9169af5a291244e99468caec3` / tree `b45556a6c4ea2d9946c73264c1ed47d4f3128a76`

The appliance does not claim physical Atari execution. It packages the bounded virtual paths so third parties can reproduce them.

## Common platforms

Linux and macOS:

```sh
./distribution/qikvrt-mesh-appliance-v1/launch-linux.sh all
```

Windows PowerShell with Docker Desktop:

```powershell
.\distribution\qikvrt-mesh-appliance-v1\launch-windows.ps1 all
```

Use `verify`, `atari`, or `firefox-effect-ack` instead of `all` to run one bounded stage.

## Immutable source download

The publication workflow creates a unique release named `qikvrt-mesh-appliance-v1-<authority-sha12>` after this work unit becomes effective on Authority main. Assets are never overwritten. The OCI image is addressed by its registry digest; the release also carries a deterministic source bundle and an amd64 bootable ISO usable with QEMU, VirtualBox or VMware. QIK-VRT Mesh Live is a Debian-derived appliance distribution, not a new kernel lineage.

Before Authority-main effect, GitHub Actions artifacts are verification evidence only and are not presented as permanent download URLs.

## Evidence boundaries

- repository evidence != virtual Hatari/Mega-ST execution
- virtual Hatari/Mega-ST execution != physical Mega-ST execution
- Firefox/browser observation != general Internet reachability
- bounded loopback terminal-input acknowledgement != general Effect-Acknowledgement
- source present on PR != published release
